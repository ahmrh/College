public class Civitas {
    /* Attribute */
    private String nama, prodi, fakultas;

    /* Behavior */
    public Civitas(String nama, String prodi, String fakultas){
        setNama(nama);
        setProdi(prodi);
        setFakultas(fakultas);
    }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getProdi() {
        return prodi;
    }
    public void setProdi(String prodi) {
        this.prodi = prodi;
    }

    public String getFakultas() {
        return fakultas;
    }
    public void setFakultas(String fakultas) {
        this.fakultas = fakultas;
    }



}
