public class Mahasiswa extends Civitas{
    /* Attribute */
    private String nim;

    /* Behavior */
    public Mahasiswa(String nim, String nama, String prodi, String fakultas){
        super(nama, prodi, fakultas);
        setNim(nim);
    }

    public String getNim(){
        return nim;
    }
    public void setNim(String nim){
        this.nim = nim;
    }
}
