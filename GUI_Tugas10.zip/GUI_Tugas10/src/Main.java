import javax.swing.*;
import java.awt.event.*;

public class Main {
    private JPanel MainPanel;
    private JButton exitButton;
    private JButton mahasiswaButton;
    private JButton dosenButton;
    private JPanel TitlePanel;
    private JPanel ButtonPanel;
    private JPanel ExitPanel;

    public Main() {

        mahasiswaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frameMhs = new JFrame("FormMahasiswa");
                FormMahasiswa formMhs = new FormMahasiswa();

                frameMhs.setContentPane(formMhs.MainPanel);
                frameMhs.pack();
                frameMhs.setSize(500,400);
                frameMhs.setVisible(true);

                formMhs.backButton.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        frameMhs.setVisible(false);
                    }
                });

                formMhs.tambahButton.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        formMhs.tambahData();
                    }
                });

                formMhs.resetButton.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        formMhs.reset();
                    }
                });

                formMhs.hapusButton.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        formMhs.hapusData();
                    }
                });

                formMhs.updateButton.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        formMhs.hapusData();
                        formMhs.tambahData();
                    }
                });

                formMhs.Tabel.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        super.mouseClicked(e);

                        formMhs.edit();
                    }
                });

            }
        });


        dosenButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frameDsn = new JFrame("FormDosen");
                FormDosen formDsn = new FormDosen();

                frameDsn.setContentPane(formDsn.MainPanel);
                frameDsn.pack();
                frameDsn.setSize(500,400);
                frameDsn.setVisible(true);

                formDsn.backButton.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        frameDsn.setVisible(false);
                    }
                });

                formDsn.tambahButton.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        formDsn.tambahData();
                    }
                });

                formDsn.resetButton.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        formDsn.reset();
                    }
                });

                formDsn.hapusButton.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        formDsn.hapusData();
                    }
                });

                formDsn.updateButton.addActionListener(new ActionListener(){
                    @Override
                    public void actionPerformed(ActionEvent e){
                        formDsn.hapusData();
                        formDsn.tambahData();
                    }
                });

                formDsn.Tabel.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        super.mouseClicked(e);

                        formDsn.edit();
                    }
                });

            }
        });


        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(1);
            }
        });
    }

    public static void main(String[] args){

        JFrame frameMain = new JFrame("Main");
        Main formMain = new Main();

        frameMain.setContentPane(formMain.MainPanel);
        frameMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameMain.pack();
        frameMain.setSize(375,300);
        frameMain.setVisible(true);


    }
}
