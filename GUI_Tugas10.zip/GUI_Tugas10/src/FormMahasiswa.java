import javax.swing.*;
import javax.swing.table.*;
import java.io.*;
import java.util.*;

public class FormMahasiswa {

    JButton backButton;
    JPanel MainPanel;
    JPanel UpperPanel;
    JPanel TitlePanel;
    JPanel InputPanel;
    JPanel TablePanel;
    JTextField NIMField;
    JTextField NamaField;
    JTextField ProdiField;
    JTextField FakultasField;
    JPanel ButtonPanel;
    JButton tambahButton;
    JButton resetButton;
    JButton hapusButton;
    JButton updateButton;
    JTable Tabel;
    JScrollPane Scroll;
    DefaultTableModel tabelModel;

    private File file;

    private String[] tabelColumns = {"NIM", "Nama", "Prodi", "Fakultas"};
    private String[][] tabelData;
    private static ArrayList<Mahasiswa> mhs = new ArrayList<Mahasiswa>();

    public FormMahasiswa(){
        Data.initMahasiswa();

        this.file = new File("resources\\mhs.txt");
        this.Tabel.setRowSelectionAllowed(true);

        try{
            BufferedReader br = new BufferedReader(new FileReader(file));
            String s;

            while((s = br.readLine()) != null){
                String[] arr = s.split("-");
                mhs.add(new Mahasiswa(arr[0], arr[1], arr[2], arr[3]));
            }

        } catch(IOException e){
            System.out.println(e);
        }

        tampilData();
    }

    public void tampilData(){
        try{
            BufferedReader br = new BufferedReader(new FileReader(file));
            int count = 0;

            while(br.readLine() != null){
                count++;
            }

            tabelData = new String[count][4];
            for(int i = 0; i < count; i++){
                if(mhs.get(i) == null){
                    continue;
                }

                tabelData[i][0] = mhs.get(i).getNim();
                tabelData[i][1] = mhs.get(i).getNama();
                tabelData[i][2] = mhs.get(i).getProdi();
                tabelData[i][3] = mhs.get(i).getFakultas();
            }

        } catch(IOException e){
            System.out.println(e);
        }


        this.tabelModel = new DefaultTableModel(tabelData, tabelColumns){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };

        this.Tabel.setModel(this.tabelModel);
        this.Scroll.setViewportView(Tabel);
        this.Tabel.setFillsViewportHeight(true);

    }

    public void tambahData(){
        String nim = NIMField.getText();
        String nama = NamaField.getText();
        String prodi = ProdiField.getText();
        String fakultas = FakultasField.getText();

        if(nim.equals("") || nama.equals("") || prodi.equals("") || fakultas.equals("")){
            return;
        }

        Mahasiswa m = new Mahasiswa(nim, nama, prodi, fakultas);
        mhs.add(m);


        updateData();
    }

    public void edit(){
        int row = this.Tabel.getSelectedRow();
        String nim = this.Tabel.getModel().getValueAt(row, 0).toString();
        String nama = this.Tabel.getModel().getValueAt(row, 1).toString();
        String prodi = this.Tabel.getModel().getValueAt(row, 2).toString();
        String fakultas = this.Tabel.getModel().getValueAt(row, 3).toString();

        this.NIMField.setText(nim);
        this.NamaField.setText(nama);
        this.ProdiField.setText(prodi);
        this.FakultasField.setText(fakultas);
    }

    public void updateData(){
        if(mhs != null){
            try{
                FileWriter writer = new FileWriter(file, false);

                for(int i = 0; i < mhs.size(); i++){
                    if(mhs.get(i) == null){
                        continue;
                    }

                    String s = "";
                    s += mhs.get(i).getNim();
                    s += "-";
                    s += mhs.get(i).getNama();
                    s += "-";
                    s += mhs.get(i).getProdi();
                    s += "-";
                    s += mhs.get(i).getFakultas();

                    writer.write(s + "\n");

                }

                writer.close();
            } catch(IOException e){
                System.out.println(e);
            }
        }

        for(Mahasiswa i : mhs){
            System.out.println("~ " + i);
        }
        System.out.println();

        tampilData();
    }

    public void hapusData(){
        int row = this.Tabel.getSelectedRow();
        mhs.remove(row);

        updateData();
    }

    public void reset(){
        this.NIMField.setText("");
        this.NamaField.setText("");
        this.ProdiField.setText("");
        this.FakultasField.setText("");
    }


}
