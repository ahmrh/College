import java.util.*;
import java.io.*;

public class Data {
    /* Attribute */
    private static ArrayList<Mahasiswa> mhs = new ArrayList<Mahasiswa>();
    private static ArrayList<Dosen> dsn = new ArrayList<Dosen>();

    /* Behavior */
    // MAHASISWA //
    public static void initMahasiswa(){
        try{
            File file = new File("resources\\mhs.txt");
            if(!file.exists()){
                file.createNewFile();
            }

            BufferedReader br = new BufferedReader(new FileReader(file));
            String s;
            while((s = br.readLine()) != null){
                System.out.println(s);
                pecahMhs(s);
            }
        }
        catch(IOException e){
            System.out.println(e);
        }
    }

    public static void pecahMhs(String data){
        String[] arr = data.split("-");
        if(arr.length < 4){
            return;
        }
        mhs.add(new Mahasiswa(arr[0], arr[1], arr[2], arr[3]));
    }

    public static void simpanMhs(){
        try{
            File file = new File("resources\\mhs.txt");
            if(!file.exists()){
                file.createNewFile();
            }
            FileWriter writer = new FileWriter(file, true);
            BufferedWriter bwriter = new BufferedWriter(writer);

            if(mhs != null){
                for(Mahasiswa i : mhs){
                    String s = "";
                    s += i.getNim();
                    s += "-";
                    s += i.getNama();
                    s += "-";
                    s += i.getProdi();
                    s += "-";
                    s += i.getFakultas();

                    bwriter.append(s + "\n");
                }
            }
            bwriter.close();
        }
        catch(IOException e){
            System.out.println(e);
        }
    }

    // DOSEN //
    public static void initDosen(){
        try{
            File file = new File("resources\\dsn.txt");
            if(!file.exists()){
                file.createNewFile();
            }

            BufferedReader br = new BufferedReader(new FileReader(file));
            String s;
            while((s = br.readLine()) != null){
                pecahDsn(s);
            }
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }

    public static void pecahDsn(String data){
        String[] arr = data.split("-");
        dsn.add(new Dosen(arr[0], arr[1], arr[2], arr[3]));
    }

    public static void simpanDsn(){
        try{
            File file = new File("resources\\dsn.txt");
            if(!file.exists()){
                file.createNewFile();
            }
            FileWriter writer = new FileWriter(file);
            if(dsn != null){
                for(Dosen i : dsn){
                    String s = "";
                    s += i.getNip();
                    s += "-";
                    s += i.getNama();
                    s += "-";
                    s += i.getProdi();
                    s += "-";
                    s += i.getFakultas();

                    writer.write(s + "\n");
                }
            }
            writer.close();
        }
        catch(IOException e){
            System.out.println(e);
        }
    }


}
