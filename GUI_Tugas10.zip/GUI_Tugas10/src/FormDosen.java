import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.util.*;

public class FormDosen {
    JPanel MainPanel;
    JButton backButton;
    JPanel UpperPanel;
    JPanel TitlePanel;
    JPanel InputPanel;
    JPanel ButtonPanel;
    JPanel TablePanel;
    JTextField NIPField;
    JTextField NamaField;
    JTextField ProdiField;
    JTextField FakultasField;
    JButton tambahButton;
    JButton resetButton;
    JButton hapusButton;
    JButton updateButton;
    JTable Tabel;
    JScrollPane Scroll;
    DefaultTableModel tabelModel;

    private File file;

    private String[] tabelColumns = {"NIP", "Nama", "Prodi", "Fakultas"};
    private String[][] tabelData;
    private static ArrayList<Dosen> dsn = new ArrayList<Dosen>();

    public FormDosen(){
        Data.initDosen();

        this.file = new File("resources\\dsn.txt");
        this.Tabel.setRowSelectionAllowed(true);

        try{
            BufferedReader br = new BufferedReader(new FileReader(file));
            String s;

            while((s = br.readLine()) != null){
                String[] arr = s.split("-");
                dsn.add(new Dosen(arr[0], arr[1], arr[2], arr[3]));
            }

        } catch(IOException e){
            System.out.println(e);
        }

        tampilData();
    }

    public void tampilData(){
        try{
            BufferedReader br = new BufferedReader(new FileReader(file));
            int count = 0;

            while(br.readLine() != null){
                count++;
            }

            tabelData = new String[count][4];
            for(int i = 0; i < count; i++){
                if(dsn.get(i) == null){
                    continue;
                }

                tabelData[i][0] = dsn.get(i).getNip();
                tabelData[i][1] = dsn.get(i).getNama();
                tabelData[i][2] = dsn.get(i).getProdi();
                tabelData[i][3] = dsn.get(i).getFakultas();
            }

        } catch(IOException e){
            System.out.println(e);
        }


        this.tabelModel = new DefaultTableModel(tabelData, tabelColumns){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };

        this.Tabel.setModel(this.tabelModel);
        this.Scroll.setViewportView(Tabel);
        this.Tabel.setFillsViewportHeight(true);

    }

    public void tambahData(){
        String nim = NIPField.getText();
        String nama = NamaField.getText();
        String prodi = ProdiField.getText();
        String fakultas = FakultasField.getText();

        if(nim.equals("") || nama.equals("") || prodi.equals("") || fakultas.equals("")){
            return;
        }

        Dosen m = new Dosen(nim, nama, prodi, fakultas);
        dsn.add(m);


        updateData();
    }

    public void edit(){
        int row = this.Tabel.getSelectedRow();
        String nim = this.Tabel.getModel().getValueAt(row, 0).toString();
        String nama = this.Tabel.getModel().getValueAt(row, 1).toString();
        String prodi = this.Tabel.getModel().getValueAt(row, 2).toString();
        String fakultas = this.Tabel.getModel().getValueAt(row, 3).toString();

        this.NIPField.setText(nim);
        this.NamaField.setText(nama);
        this.ProdiField.setText(prodi);
        this.FakultasField.setText(fakultas);
    }

    public void updateData(){
        if(dsn != null){
            try{
                FileWriter writer = new FileWriter(file, false);

                for(int i = 0; i < dsn.size(); i++){
                    if(dsn.get(i) == null){
                        continue;
                    }

                    String s = "";
                    s += dsn.get(i).getNip();
                    s += "-";
                    s += dsn.get(i).getNama();
                    s += "-";
                    s += dsn.get(i).getProdi();
                    s += "-";
                    s += dsn.get(i).getFakultas();

                    writer.write(s + "\n");

                }

                writer.close();
            } catch(IOException e){
                System.out.println(e);
            }
        }

        for(Dosen i : dsn){
            System.out.println("~ " + i);
        }
        System.out.println();

        tampilData();
    }

    public void hapusData(){
        int row = this.Tabel.getSelectedRow();
        dsn.remove(row);

        updateData();
    }

    public void reset(){
        this.NIPField.setText("");
        this.NamaField.setText("");
        this.ProdiField.setText("");
        this.FakultasField.setText("");
    }

}
